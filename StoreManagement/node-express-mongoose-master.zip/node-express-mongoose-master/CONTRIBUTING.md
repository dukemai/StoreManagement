Please refer to [express style guide](https://github.com/expressjs/style-guide/blob/master/javascript.md)
